using System.Runtime.CompilerServices;
using SageEngine;

namespace SageEngine
{
    
    public class Component
    {
       


        public GameObject gameObject;
        public Transform transform;


    }
}